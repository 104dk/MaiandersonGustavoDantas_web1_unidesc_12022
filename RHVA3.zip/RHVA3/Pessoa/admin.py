from django.contrib import admin
from .models import Pessoa

admin.site.register(Pessoa)