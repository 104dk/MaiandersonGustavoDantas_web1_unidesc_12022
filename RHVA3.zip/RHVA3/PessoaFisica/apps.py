from django.apps import AppConfig


class PessoafisicaConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'PessoaFisica'
