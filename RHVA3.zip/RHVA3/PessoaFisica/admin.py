from django.contrib import admin
from .models import PessoaFisica

admin.site.register(PessoaFisica)