from django.contrib import admin
from .models import Corretor

admin.site.register(Corretor)