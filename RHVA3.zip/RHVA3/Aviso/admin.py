from django.contrib import admin
from .models import Aviso

admin.site.register(Aviso)