from django.contrib import admin
from .models import Deposito

admin.site.register(Deposito)