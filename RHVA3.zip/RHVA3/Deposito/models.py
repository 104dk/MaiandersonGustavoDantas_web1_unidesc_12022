from django.db import models

class Deposito(models.Model):

    idDeposito = models.CharField(max_length=100)