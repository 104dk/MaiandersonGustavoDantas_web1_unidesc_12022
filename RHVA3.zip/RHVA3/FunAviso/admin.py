from django.contrib import admin
from .models import FunAviso

admin.site.register(FunAviso)