from django.apps import AppConfig


class RenovacaoConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'Renovacao'
