from django.contrib import admin
from .models import Renovacao

admin.site.register(Renovacao)