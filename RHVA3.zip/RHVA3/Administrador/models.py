from django.db import models

class Administrador(models.Model):

    def calcular_Salario(self):
        return 0