from django.contrib import admin
from .models import CliAviso

admin.site.register(CliAviso)