from django.apps import AppConfig


class CliavisoConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'CliAviso'
