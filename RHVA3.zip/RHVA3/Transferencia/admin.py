from django.contrib import admin
from .models import Transferencia

admin.site.register(Transferencia)