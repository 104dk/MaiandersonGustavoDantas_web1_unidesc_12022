from django.contrib import admin
from .models import Pagamento

admin.site.register(Pagamento)