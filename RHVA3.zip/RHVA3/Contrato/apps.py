from django.apps import AppConfig


class ContratoConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'Contrato'
