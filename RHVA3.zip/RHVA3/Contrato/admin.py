from django.contrib import admin
from .models import Contrato

admin.site.register(Contrato)