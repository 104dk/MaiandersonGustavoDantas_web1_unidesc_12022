from django.contrib import admin
from .models import Imovel

admin.site.register(Imovel)