from django.contrib import admin
from .models import itemImovel

admin.site.register(itemImovel)