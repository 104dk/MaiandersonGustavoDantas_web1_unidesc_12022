from django.apps import AppConfig


class ItemimovelConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'ItemImovel'
