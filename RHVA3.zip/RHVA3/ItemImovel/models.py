from django.db import models

class itemImovel(models.Model):

    fotos = models.CharField(max_length=100)