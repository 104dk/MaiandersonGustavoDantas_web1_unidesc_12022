from django.contrib import admin
from .models import Gerente

admin.site.register(Gerente)